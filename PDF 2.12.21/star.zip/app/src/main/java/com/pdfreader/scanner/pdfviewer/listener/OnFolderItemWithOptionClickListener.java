package com.pdfreader.scanner.pdfviewer.listener;

public interface OnFolderItemWithOptionClickListener {
    void onClickItem(int position);

}
