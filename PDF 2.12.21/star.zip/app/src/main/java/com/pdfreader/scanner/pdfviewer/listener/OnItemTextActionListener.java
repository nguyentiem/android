package com.pdfreader.scanner.pdfviewer.listener;

public interface OnItemTextActionListener {
    void onClick(int position);
    void onOption(int position);
}
