package com.pdfreader.scanner.pdfviewer.ui.main;

public interface MainNavigator {
}
