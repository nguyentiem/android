package com.pdfreader.scanner.pdfviewer.ui.bookmark;

public interface BookmarkNavigator {
}
