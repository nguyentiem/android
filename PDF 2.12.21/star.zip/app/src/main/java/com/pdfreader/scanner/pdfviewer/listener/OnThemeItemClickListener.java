package com.pdfreader.scanner.pdfviewer.listener;

public interface OnThemeItemClickListener {
    void onClickItem(int position);
}
