package com.pdfreader.scanner.pdfviewer.ui.viewpdf;

public interface ViewPdfNavigator {
}
