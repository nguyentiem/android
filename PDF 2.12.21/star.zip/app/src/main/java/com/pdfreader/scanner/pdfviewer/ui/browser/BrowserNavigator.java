package com.pdfreader.scanner.pdfviewer.ui.browser;

public interface BrowserNavigator {
}
