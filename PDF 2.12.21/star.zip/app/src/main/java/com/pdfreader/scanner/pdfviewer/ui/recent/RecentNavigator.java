package com.pdfreader.scanner.pdfviewer.ui.recent;

public interface RecentNavigator {
}
