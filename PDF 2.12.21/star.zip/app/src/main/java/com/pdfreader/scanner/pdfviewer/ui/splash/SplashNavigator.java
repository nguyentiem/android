package com.pdfreader.scanner.pdfviewer.ui.splash;

public interface SplashNavigator {
}
