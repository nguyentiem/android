package com.pdfreader.scanner.pdfviewer.ui.cropimage;

import android.app.Application;

import androidx.annotation.NonNull;

import com.pdfreader.scanner.pdfviewer.ui.base.BaseViewModel;

public class CropImageViewModel extends BaseViewModel {
    public CropImageViewModel(@NonNull Application application) {
        super(application);
    }
}
