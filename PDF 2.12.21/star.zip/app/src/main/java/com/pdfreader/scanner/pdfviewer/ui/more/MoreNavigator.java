package com.pdfreader.scanner.pdfviewer.ui.more;

public interface MoreNavigator {
}
