package com.pdfreader.scanner.pdfviewer.ui.merge;

public interface MergeNavigator {
}
