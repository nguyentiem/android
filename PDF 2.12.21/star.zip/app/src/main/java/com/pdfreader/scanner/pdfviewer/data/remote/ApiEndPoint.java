package com.pdfreader.scanner.pdfviewer.data.remote;

public class ApiEndPoint {
    public static String getEndPointImage(Object imageOwner) {
        return "";
    }
}
