package com.pdfreader.scanner.pdfviewer.ui.formatpdf;

public interface FormatPdfNavigator {
}
