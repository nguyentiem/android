package com.pdfreader.scanner.pdfviewer.listener;

public interface OnFileItemClickListener {
    void onClickItem(int position);
}
