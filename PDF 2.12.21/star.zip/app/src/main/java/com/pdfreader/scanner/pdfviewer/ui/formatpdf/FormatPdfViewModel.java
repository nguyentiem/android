package com.pdfreader.scanner.pdfviewer.ui.formatpdf;

import android.app.Application;

import androidx.annotation.NonNull;

import com.pdfreader.scanner.pdfviewer.ui.base.BaseViewModel;

public class FormatPdfViewModel extends BaseViewModel<FormatPdfNavigator> {
    public FormatPdfViewModel(@NonNull Application application) {
        super(application);
    }
}
