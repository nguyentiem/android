package com.pdfreader.scanner.pdfviewer.ui.imageview;

public interface ImageViewNavigator {
}
