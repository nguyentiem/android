package com.pdfreader.scanner.pdfviewer.ui.lib;

public interface LibNavigator {
}
