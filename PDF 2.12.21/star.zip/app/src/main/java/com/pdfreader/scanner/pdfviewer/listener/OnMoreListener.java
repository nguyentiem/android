package com.pdfreader.scanner.pdfviewer.listener;

public interface OnMoreListener {
    void fileManageClick();
    void remoteAddClick();
    void feedBackClick();
    void shareAppClick();
    void rateUsClick();
}
