package com.pdfreader.scanner.pdfviewer.data.remote;

public interface ApiHelperInterface {
}
