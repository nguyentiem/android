package com.pdfreader.scanner.pdfviewer.listener;

public interface OnDataOptionClickListener {
    void onClickItem(int position);
}
