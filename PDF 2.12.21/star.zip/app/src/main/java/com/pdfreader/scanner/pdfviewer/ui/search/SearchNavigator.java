package com.pdfreader.scanner.pdfviewer.ui.search;

public interface SearchNavigator {
    void showNoData();
}
