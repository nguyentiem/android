package com.pdfreader.scanner.pdfviewer.ui.pdftoimage;

public interface PdfToImageNavigator {
}
