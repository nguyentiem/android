"# PhotoPDF project" 

All UI package -> ui
Naming String / Dimens  -> "<name_class_or_xml_file_using>_<name_string>", for example, fragment_home_hello_text
Naming Color: natural language
Naming class: activity: <Name_mean>Activity, for example, HomeActivity
              fragment: <Name_mean>Fragment, for example, HomeFragment
All activity transition need to defined in BaseActivity
