/**
 * Commonly used classes and helper functions.
 */
package de.syss.MifareClassicTool;